import { useEffect, useMemo, useState } from 'react';
import { ArrowDown, ArrowRight, Check, ChevronDown, Minus, Plus, Search, ShoppingBag, SlidersHorizontal, X } from 'lucide-react';

type Product = {
  id: string;
  name: string;
  category: string;
  price: number;
  image: string;
  badge?: string;
};

type Cart = Record<string, number>;

const products: Product[] = [
  { id: 'bottle', name: 'Термокружка «Ритм»', category: 'Для дома', price: 1490, image: 'https://images.pexels.com/photos/1207918/pexels-photo-1207918.jpeg?auto=compress&cs=tinysrgb&w=900', badge: 'Хит недели' },
  { id: 'lamp', name: 'Настольная лампа «Форма»', category: 'Для дома', price: 3290, image: 'https://images.pexels.com/photos/1112598/pexels-photo-1112598.jpeg?auto=compress&cs=tinysrgb&w=900', badge: 'Новая цена' },
  { id: 'speaker', name: 'Портативная колонка «Мини»', category: 'Техника', price: 4590, image: 'https://images.pexels.com/photos/1279107/pexels-photo-1279107.jpeg?auto=compress&cs=tinysrgb&w=900' },
  { id: 'tote', name: 'Сумка-шопер «Каждый день»', category: 'Аксессуары', price: 890, image: 'https://images.pexels.com/photos/5709665/pexels-photo-5709665.jpeg?auto=compress&cs=tinysrgb&w=900' },
  { id: 'scissors', name: 'Ножницы кухонные «Линия»', category: 'Для дома', price: 790, image: 'https://images.pexels.com/photos/4226896/pexels-photo-4226896.jpeg?auto=compress&cs=tinysrgb&w=900' },
  { id: 'headphones', name: 'Наушники «Поток»', category: 'Техника', price: 2790, image: 'https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg?auto=compress&cs=tinysrgb&w=900', badge: 'Выбор команды' },
  { id: 'notebook', name: 'Блокнот «Планы и идеи»', category: 'Для себя', price: 590, image: 'https://images.pexels.com/photos/733857/pexels-photo-733857.jpeg?auto=compress&cs=tinysrgb&w=900' },
  { id: 'bedding', name: 'Мягкий плед «Облако»', category: 'Для дома', price: 2490, image: 'https://images.pexels.com/photos/6444268/pexels-photo-6444268.jpeg?auto=compress&cs=tinysrgb&w=900' },
  { id: 'bottle2', name: 'Бутылка для воды «Движение»', category: 'Для себя', price: 990, image: 'https://images.pexels.com/photos/3766186/pexels-photo-3766186.jpeg?auto=compress&cs=tinysrgb&w=900' },
  { id: 'storage', name: 'Органайзер для мелочей', category: 'Для дома', price: 1190, image: 'https://images.pexels.com/photos/4239031/pexels-photo-4239031.jpeg?auto=compress&cs=tinysrgb&w=900' },
  { id: 'watch', name: 'Настенные часы «Линия»', category: 'Для дома', price: 2190, image: 'https://images.pexels.com/photos/707676/pexels-photo-707676.jpeg?auto=compress&cs=tinysrgb&w=900' },
  { id: 'soap', name: 'Набор ароматного мыла', category: 'Для себя', price: 690, image: 'https://images.pexels.com/photos/6621465/pexels-photo-6621465.jpeg?auto=compress&cs=tinysrgb&w=900' },
];

const categories = ['Всё', 'Для дома', 'Техника', 'Для себя', 'Аксессуары'];
const money = (value: number) => `${new Intl.NumberFormat('ru-RU').format(value)} ₽`;

function readCart(): Cart {
  try {
    const stored = localStorage.getItem('veroxa-cart');
    return stored ? JSON.parse(stored) as Cart : {};
  } catch {
    return {};
  }
}

function App() {
  const [cart, setCart] = useState<Cart>(readCart);
  const [category, setCategory] = useState('Всё');
  const [query, setQuery] = useState('');
  const [cartOpen, setCartOpen] = useState(false);
  const [sort, setSort] = useState<'popular' | 'low' | 'high'>('popular');
  const [notice, setNotice] = useState('');

  useEffect(() => {
    localStorage.setItem('veroxa-cart', JSON.stringify(cart));
  }, [cart]);

  const visibleProducts = useMemo(() => {
    const normalized = query.trim().toLocaleLowerCase('ru');
    const filtered = products.filter((product) =>
      (category === 'Всё' || product.category === category) &&
      (!normalized || `${product.name} ${product.category}`.toLocaleLowerCase('ru').includes(normalized)),
    );
    if (sort === 'low') filtered.sort((a, b) => a.price - b.price);
    if (sort === 'high') filtered.sort((a, b) => b.price - a.price);
    return filtered;
  }, [category, query, sort]);

  const cartItems = products.filter((product) => (cart[product.id] ?? 0) > 0);
  const itemCount = Object.values(cart).reduce((sum, amount) => sum + amount, 0);
  const total = cartItems.reduce((sum, product) => sum + product.price * cart[product.id], 0);

  const addToCart = (product: Product) => {
    setCart((current) => ({ ...current, [product.id]: (current[product.id] ?? 0) + 1 }));
    setNotice(`${product.name} добавлен в корзину`);
    window.setTimeout(() => setNotice(''), 2200);
  };
  const changeQuantity = (id: string, delta: number) => {
    setCart((current) => {
      const next = { ...current };
      const amount = (next[id] ?? 0) + delta;
      if (amount <= 0) delete next[id];
      else next[id] = amount;
      return next;
    });
  };

  return (
    <main className="site-shell">
      <header className="topbar">
        <a className="brand" href="/" aria-label="VEROXA — на главную" data-testid="link-home">
          <span className="brand-mark">V</span><span>VEROXA</span>
        </a>
        <nav className="desktop-nav" aria-label="Основная навигация">
          <a href="#catalog" data-testid="link-catalog">Каталог</a>
          <a href="#about" data-testid="link-about">О нас</a>
        </nav>
        <div className="topbar-actions">
          <span className="delivery-note"><span className="delivery-dot" /> Демо-каталог</span>
          <button className="cart-trigger" onClick={() => setCartOpen(true)} aria-label={`Корзина, товаров: ${itemCount}`} data-testid="button-open-cart">
            <ShoppingBag size={19} strokeWidth={1.8} />
            <span className="cart-label">Корзина</span>
            <span className="cart-count" data-testid="text-cart-count">{itemCount}</span>
          </button>
        </div>
      </header>

      <section className="hero" aria-labelledby="hero-heading">
        <div className="hero-copy">
          <div className="eyebrow"><span className="eyebrow-line" /> ВЕЩИ ДЛЯ ЖИЗНИ, А НЕ ДЛЯ ПОЛКИ</div>
          <h1 id="hero-heading" className="display-font">Хорошее<br />рядом<span className="hero-period">.</span></h1>
          <p>Полезные находки для дома, работы и всего между ними. Выбрали за вас — осталось выбрать своё.</p>
          <a href="#catalog" className="hero-link" data-testid="link-to-catalog">Смотреть каталог <ArrowDown size={16} /></a>
          <div className="hero-footnote"><span>01 / 01</span><span className="footnote-rule" /><span>Подборка для обычных дней</span></div>
        </div>
        <div className="hero-art">
          <div className="art-orbit orbit-one" /><div className="art-orbit orbit-two" />
          <div className="hero-sun" />
          <div className="hero-image-wrap"><img src="https://images.pexels.com/photos/4210854/pexels-photo-4210854.jpeg?auto=compress&cs=tinysrgb&w=1200" alt="Уютная композиция из предметов для дома" /></div>
          <div className="art-stamp"><span>ОТБОР<br />VEROXA</span><span className="stamp-star" aria-hidden="true" /></div>
          <div className="art-caption">ПРОСТЫЕ ВЕЩИ.<br />ХОРОШИЙ ВЫБОР.</div>
          <div className="art-index">КОЛЛЕКЦИЯ 01 — 2026</div>
        </div>
      </section>

      <section className="promise-strip" id="about">
        <div className="promise-label">ПОЧЕМУ VEROXA</div>
        <div className="promise"><span className="promise-number">01</span><span>Только то, что пригодится</span></div>
        <div className="promise"><span className="promise-number">02</span><span>Честные цены без сюрпризов</span></div>
        <div className="promise"><span className="promise-number">03</span><span>Корзина считает сумму сразу</span></div>
      </section>

      <section className="catalog-section" id="catalog">
        <div className="catalog-heading">
          <div>
            <div className="eyebrow catalog-eyebrow"><span className="eyebrow-line" /> НАЙДИТЕ СВОЁ</div>
            <h2 className="display-font">Выбрали для вас<span>.</span></h2>
          </div>
          <p className="catalog-intro">Каждая вещь здесь — с понятной пользой и своим местом в повседневной жизни.</p>
        </div>
        <div className="catalog-tools">
          <div className="category-list" role="group" aria-label="Фильтр по категориям">
            {categories.map((item) => (
              <button key={item} onClick={() => setCategory(item)} className={`category-chip ${category === item ? 'selected' : ''}`} aria-pressed={category === item} data-testid={`filter-category-${item === 'Всё' ? 'all' : item.toLowerCase().replaceAll(' ', '-')}`}>
                {item}
              </button>
            ))}
          </div>
          <div className="catalog-controls">
            <label className="search-box">
              <Search size={17} />
              <input type="search" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Найти вещь" aria-label="Поиск товаров" data-testid="input-search" />
              {query && <button type="button" className="clear-search" aria-label="Очистить поиск" onClick={() => setQuery('')} data-testid="button-clear-search"><X size={15} /></button>}
            </label>
            <label className="sort-select">
              <SlidersHorizontal size={16} />
              <select value={sort} onChange={(event) => setSort(event.target.value as 'popular' | 'low' | 'high')} aria-label="Сортировка товаров" data-testid="select-sort">
                <option value="popular">Сначала популярное</option>
                <option value="low">Сначала дешевле</option>
                <option value="high">Сначала дороже</option>
              </select>
              <ChevronDown size={14} className="sort-chevron" />
            </label>
          </div>
        </div>

        <div className="result-line" aria-live="polite" data-testid="text-result-count">
          <span>{query || category !== 'Всё' ? `Найдено: ${visibleProducts.length}` : 'Популярное сейчас'}</span>
          <span className="result-count">{String(visibleProducts.length).padStart(2, '0')} товара</span>
        </div>

        {visibleProducts.length ? (
          <div className="product-grid" data-testid="grid-products">
            {visibleProducts.map((product, index) => {
              const amount = cart[product.id] ?? 0;
              return (
                <article className="product-card" key={product.id} data-testid={`card-product-${product.id}`} style={{ animationDelay: `${Math.min(index * 35, 240)}ms` }}>
                  <div className="product-visual">
                    <img src={product.image} alt={product.name} loading="lazy" data-testid={`img-product-${product.id}`} />
                    {product.badge && <span className="product-badge" data-testid={`badge-product-${product.id}`}>{product.badge}</span>}
                    <span className="product-category">{product.category}</span>
                  </div>
                  <div className="product-details">
                    <div className="product-title-line">
                      <h3 data-testid={`text-product-name-${product.id}`}>{product.name}</h3>
                      <span className="product-price" data-testid={`text-product-price-${product.id}`}>{money(product.price)}</span>
                    </div>
                    <button className={`add-button ${amount > 0 ? 'is-added' : ''}`} onClick={() => addToCart(product)} data-testid={`button-add-${product.id}`} aria-label={amount > 0 ? `Добавить ещё: ${product.name}` : `Добавить в корзину: ${product.name}`}>
                      {amount > 0 ? <><Check size={15} /> В корзине · {amount}</> : <>В корзину <Plus size={15} /></>}
                    </button>
                  </div>
                </article>
              );
            })}
          </div>
        ) : (
          <div className="empty-results" data-testid="empty-search">
            <div className="empty-mark"><Search size={22} /></div>
            <h3>Таких находок пока нет</h3>
            <p>Попробуйте другое слово или выберите другую категорию.</p>
            <button onClick={() => { setQuery(''); setCategory('Всё'); }} data-testid="button-reset-filters">Сбросить фильтры <ArrowRight size={15} /></button>
          </div>
        )}
      </section>

      <section className="closing-band">
        <div className="closing-mark">V.</div>
        <div><div className="eyebrow"><span className="eyebrow-line" /> МЕНЬШЕ ПОИСКА — БОЛЬШЕ ЖИЗНИ</div><h2 className="display-font">Выбирайте<br />с удовольствием.</h2></div>
        <a href="#catalog" className="closing-button" data-testid="link-back-to-catalog">К покупкам <ArrowRight size={17} /></a>
      </section>

      <footer className="footer">
        <a className="brand footer-brand" href="/" data-testid="link-footer-home"><span className="brand-mark">V</span><span>VEROXA</span></a>
        <span>Хорошие вещи для обычных дней.</span>
        <span className="footer-note">ДЕМО-МАГАЗИН · 2026</span>
      </footer>

      {notice && <div role="status" className="toast-message" data-testid="status-added-to-cart"><Check size={16} />{notice}</div>}
      {cartOpen && (
        <div className="drawer-scrim" onClick={() => setCartOpen(false)} role="presentation">
          <aside className="cart-drawer" role="dialog" aria-modal="true" aria-labelledby="cart-heading" onClick={(event) => event.stopPropagation()} data-testid="panel-cart">
            <div className="drawer-head"><div><div className="eyebrow"><span className="eyebrow-line" /> ВАШ ВЫБОР</div><h2 className="display-font" id="cart-heading">Корзина<span>.</span></h2></div><button className="icon-button" onClick={() => setCartOpen(false)} aria-label="Закрыть корзину" data-testid="button-close-cart"><X size={20} /></button></div>
            {cartItems.length ? (
              <>
                <div className="cart-items">
                  {cartItems.map((product) => (
                    <div className="cart-row" key={product.id} data-testid={`row-cart-${product.id}`}>
                      <img src={product.image} alt="" />
                      <div className="cart-row-info"><h3>{product.name}</h3><span>{money(product.price)}</span><div className="quantity-control">
                        <button onClick={() => changeQuantity(product.id, -1)} aria-label={`Уменьшить количество: ${product.name}`} data-testid={`button-decrease-${product.id}`}><Minus size={13} /></button>
                        <span data-testid={`text-quantity-${product.id}`}>{cart[product.id]}</span>
                        <button onClick={() => changeQuantity(product.id, 1)} aria-label={`Увеличить количество: ${product.name}`} data-testid={`button-increase-${product.id}`}><Plus size={13} /></button>
                      </div></div>
                      <strong className="cart-line-total">{money(product.price * cart[product.id])}</strong>
                    </div>
                  ))}
                </div>
                <div className="cart-summary">
                  <div className="summary-row"><span>Товаров</span><span data-testid="text-cart-items-total">{itemCount}</span></div>
                  <div className="summary-row"><span>Доставка</span><span>Не учитывается в демо</span></div>
                  <div className="summary-total"><span>Итого</span><strong data-testid="text-cart-total">{money(total)}</strong></div>
                  <button className="checkout-button" onClick={() => setCartOpen(false)} data-testid="button-checkout">Вернуться к покупкам <ArrowRight size={17} /></button>
                  <p>Демо-корзина сохраняется на этом устройстве.</p>
                </div>
              </>
            ) : (
              <div className="empty-cart" data-testid="empty-cart">
                <div className="empty-mark"><ShoppingBag size={23} /></div>
                <h3>Пока здесь пусто</h3>
                <p>Добавьте что-нибудь полезное — корзина всё запомнит.</p>
                <button onClick={() => setCartOpen(false)} data-testid="button-empty-cart-shop">Перейти к покупкам <ArrowRight size={15} /></button>
              </div>
            )}
          </aside>
        </div>
      )}
    </main>
  );
}

export default App;
